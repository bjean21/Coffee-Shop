-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Mar 20, 2025 at 07:18 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cafe`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `comment` text NOT NULL,
  `feedback_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_approved` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `customer_name`, `comment`, `feedback_date`, `is_approved`) VALUES
(3, 'christine', 'so cutie pie', '2025-03-12 05:24:31', 1),
(4, 'christine', 'so cutie pie', '2025-03-12 05:24:59', 0),
(5, 'christine', 'im cute', '2025-03-12 05:26:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `item_name`, `category`, `price`, `image`) VALUES
(1, 'Muffins', 'Pastries', 40.00, 'images/muffins.jpg'),
(2, 'Croissants', 'Pastries', 100.00, 'images/croissants.jpg'),
(3, 'Scones', 'Pastries', 35.00, 'images/scones.jpg'),
(4, 'Bagels', 'Pastries', 200.00, 'images/bagels.jpg'),
(5, 'Cinnamon Rolls', 'Pastries', 150.00, 'images/cinnamon.jpg'),
(6, 'Cookies', 'Pastries', 90.00, 'images/cookies.jpg'),
(7, 'Frozen Hot Chocolate', 'Classics', 90.00, 'images/frozen.jpg'),
(8, 'Hot Chocolate', 'Classics', 70.00, 'images/hotChocolate.jpg'),
(9, 'Velvet Cream', 'Classics', 25.00, 'images/velvet.jpg'),
(10, 'Frozen Lemonade', 'Classics', 30.00, 'images/lemonade.jpg'),
(11, 'Vienna Creme', 'Coffee', 25.00, 'images/vienna.jpg'),
(12, 'Caramel', 'Coffee', 110.00, 'images/caramel.jpg'),
(13, 'Hot Mocha', 'Coffee', 50.00, 'images/hotMocha.jpg'),
(14, 'Hot Coffee', 'Coffee', 90.00, 'images/hotCoffee.jpg'),
(15, 'Skinny Vanilla Latte', 'Espresso', 30.00, 'images/skinny.jpg'),
(16, 'Cafe Latte', 'Espresso', 49.00, 'images/cafeLatte.jpg'),
(17, 'Mocha Latte', 'Espresso', 25.00, 'images/mochaLatte.jpg'),
(18, 'White Chocolate Latte', 'Espresso', 50.00, 'images/whiteChocolate.jpg'),
(20, 'Mocha Cappuccino', 'Espresso', 20.00, 'images/mochaCappu.jpg'),
(21, 'Iced Coffee', 'Iced Coffee', 45.00, 'images/icedCoffee.jpg'),
(22, 'Iced Mocha', 'Iced Coffee', 40.20, 'images/icedMocha.jpg'),
(23, 'Iced Latte', 'Iced Coffee', 45.00, 'images/icedLatte.jpg'),
(24, 'Nitro', 'Iced Coffee', 40.00, 'images/nitro.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `order_details` text NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','gcash') NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `items_ordered` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_name`, `order_details`, `total_amount`, `payment_method`, `order_date`, `items_ordered`) VALUES
(20, 'aa', '', 0.00, 'cash', '2025-03-19 04:33:56', 'Caramel (₱110.00)'),
(21, 'ado', '', 0.00, 'cash', '2025-03-19 04:34:16', 'Frozen Hot Chocolate (₱90.00)'),
(22, 'xa', '', 0.00, 'cash', '2025-03-19 04:35:03', 'Frozen Hot Chocolate (₱90.00)'),
(23, 'sa', '', 0.00, 'cash', '2025-03-19 04:37:39', 'Frozen Hot Chocolate (₱90.00)'),
(25, 'van', '', 0.00, 'cash', '2025-03-19 04:42:02', 'Frozen Hot Chocolate (₱90.00)'),
(26, 'vans', '', 90.00, 'cash', '2025-03-19 04:43:32', 'Frozen Hot Chocolate (₱90.00)'),
(27, 'anns', '', 90.00, 'cash', '2025-03-19 04:44:15', 'Cookies (₱90.00)'),
(28, 'how', '', 70.00, 'cash', '2025-03-19 04:44:36', 'Hot Chocolate (₱70.00)'),
(29, 'hgh', '', 25.00, 'cash', '2025-03-19 06:15:27', 'Velvet Cream (₱25.00)'),
(30, 'didat', '', 90.00, 'cash', '2025-03-19 06:20:35', 'Frozen Hot Chocolate (₱90.00)'),
(31, 'christinej', '', 90.00, 'cash', '2025-03-19 06:28:01', 'Frozen Hot Chocolate (₱90.00)');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','customer') DEFAULT 'customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'admin', 'admin123', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `stock`
--
ALTER TABLE `stock`
  ADD CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `menu` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
